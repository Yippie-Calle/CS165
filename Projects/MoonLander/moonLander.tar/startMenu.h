//
//      startMenu.h
//      startMenu
//
//

#ifndef startMenu_h
#define startMenu_h

class Start
{
private:
	char option;
	char response;
public:
	void startMenuOptions();
	void executeCommand();
	void instructions();
	void playAgain();

};


#endif